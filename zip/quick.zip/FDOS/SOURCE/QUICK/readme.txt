Hello, friends !

       Here you have the most complex QB program ever seen!
 Quick.exe is a powerful hardware detection program that
 provides valuable info about devices installed in your system.

 If you find this program or source files useful, please make a donation
 to us. See our page for details:

 www.quickexe.go.ro
 and mail adress:
 quickexe@hotmail.com


Quick.bas - main program
quick.bi - all procedure & function declarations, constants, variables
proc.bas, addon.bas, aim.bas etc - additonal modules


Written for QuickBasic 4.5 vesion.


In order to compile Quick.exe follow three steps:
1) (optional) copy ALL files from QUICKSRC folder in your QuickBasic folder.
I included in this archive QB.EXE, bc.exe, link.exe and brun45.lib,com45.lib,
so you can compile our program without copying source files if you work in
original QUICKSRC folder.

Note that you need all files (.bas, .lib, .obj, .txt). Text files are databases
for main program, and will be included in the final executable.


2) Compile all .bas modules excepting quick.bas. Use BC [filename] command.

E.g.: BC addon
	BC aim
	BC biosproc
	BC collect
	BC proc

Press enter when compiler ask you about resulting filenames, so .obj
files will have the same name as the source .bas files:
addon.obj, aim.obj, biosproc.obj, collect.obj, proc.obj.

3) Now you'll compile the main program. For this, run quick.bat file.
Press enter to all compiler questions.
You'll see "There were 2 errors detected", but it's OK.

That's all!

Now you can run quick.exe. Best results are obtained in DOS, but this program
also works well under any Windows OS.

Sorry, no documentation available about source code, docs are only in my mind.
For details, visit www.quickexe.go.ro page.

If you have any question regarding program or source code, please e-mail me
at quickexe@hotmail.com. I'd like to see your comments.


Best regards,
Mikerinos Altermann (Mike for friends).
Code, docs, hints, ideas, comments and DONATIONS are wellcome !!!