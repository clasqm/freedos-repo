/* Reads a Gutenburg text file and joins the paragraphs together */

#include <stdio.h>
#include <string.h>

/* does c appear in s ignoring case */
int instr(char *s,char *c) {
    char ss[900];
    strcpy(ss,s);
    strlwr(ss);
    strlwr(c);
    if(strstr(ss,c) != NULL)
        return 1;
    return 0;
}

/* is every character white space */
int isAllWhitespace(char *s) {
    char *c;

    c = s;
    while(*c)
        if(! isspace(*c++))
            return 0;
    return 1;
}

int checkXML=0;

void sendLine(char *s) {
    if(checkXML) {
        if(isAllWhitespace(s))
            return;
        printf("    <LINE>%s</LINE>\n",s);
        }
    else
        printf("%s\n\n",s);
}

    /* end marker variables */
    int checkEnd=0;
    int findEnd=0;
    char endMarker[100];

void getArgs(int argc,char * argv[]) {

     int i;
     for(i=1; i < argc; i++) {
         /* The /e switch searches for the *end* marker in the text */
         if(stricmp(argv[i],"/e") == 0) {
             strcpy(endMarker,"*end*");  /* default end marker */
             checkEnd=1;
             findEnd=1;
             if(argc > i)    /* is there a next argument */
                if(*argv[i+1] != '/')  /* and it is not the next arg */
                    {
                      strcpy(endMarker,argv[i+1]);
                      i++;
                    }
             }
         /* /x outputs to XML */
         if(stricmp(argv[i],"/x") == 0)
             checkXML=1;
         }


}

int main(int argc,char * argv[]) {


     if(argc<=1){
        printf("Gutenberg Reader 0.1.1 July 2005 \n");
        printf("removes unwanted carriage returns in Gutenberg text files\n\n");
        printf("usage: gutread <file_in> [/e[ <>]] [/x]\n");
        printf("  /e : does not output text before the *end* marker\n");
        printf("       a different end marker may be specified by adding\n");
        printf("       the search text after the /e.\n");
        printf("in the Gutenberg text file\n");
        printf("  /x : output in XML\n\n");
        printf("use the file redirector > to send to a new file\n");
        printf("eg\n  gutread iliad.txt > my_iliad.txt\n\n");
        printf("  gutread iliad.txt /e *** /x > my_iliad.txt\n\n");
        printf("  gutread iliad.txt /e \"end of text\" /x > my_iliad.txt\n");
        return 0;
     }



     getArgs(argc,argv);

     
     FILE *f;

     f=fopen(argv[1],"rt");
     if(f==NULL) {
                 printf("%s cannot be opened.\n",argv[1]);
                 return 1;
     }
     char s[1000], theLine[90000];
     char *r;

     *theLine = 0;
     /* output first tag if XML */
     if(checkXML)
         printf("<STORY>\n");
     r=fgets(s,499,f);
     while(r != NULL) {
             if(!checkEnd) {
                 if(strlen(s)==1) { /* just newline */
                     sendLine(theLine);
                     theLine[0]=0;
                     }
             else {
                 /* chop off last character - newline */
                 if(s[strlen(s)-1] == 10)
                     s[strlen(s)-1]=0;
                 if(strlen(theLine) == 0)
                     strcpy(theLine,s);
                 else {
                     strcat(theLine," ");
                     strcat(theLine,s);
                     }
                 }
             }
             else if(instr(s,endMarker))
                 checkEnd = 0;
                 
             r=fgets(s,199,f);
     }
     /* output remaining line if there */
     if(strlen(theLine) > 0)
         sendLine(theLine);
     /* complete XML */
     if(checkXML)
         printf("</STORY>");
     if(findEnd & checkEnd)
         printf("End of header text '%s' not found in file %s",endMarker,argv[1]);
     fclose(f);
}
