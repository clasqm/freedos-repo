/*-----------------------------------------------------------
	error.c
	
	very primitive error handler
	
	William May
	303A Ridgefield Circle
	Clinton, MA 01510
  -----------------------------------------------------------*/

#include <stdio.h>

/*-----------------------------------------------------------
	if an error number specified then print it,
	otherwise only print the message
 -----------------------------------------------------------*/
syserr(errno, s)
int errno;
char *s;
{
	if (errno) printf("Error (%d): %s\n", errno, s);
	else printf("Error: %s\n", s);
	
	ExitToShell();
}
