README.TXT     18-Aug-2020

Snarf is a screen capture utility for DOS. It saves whatever is on the
screen to a file. It works for all text and graphic modes: CGA, EGA, VGA,
and VESA version 3.0, including images in a linear frame buffer. It also
works from a DOS prompt under 32-bit versions of Windows, such as XP.

When run, Snarf is installed into about 4K of memory as a Terminate-and-
Stay-Resident (TSR) program. Pressing Alt+S captures the screen. A beep
indicates the image is being saved to disk. A second beep indicates the
capture is complete. The image is saved in the current directory (or
folder) in a file called SNARF000.BMP. Additional images are saved in
SNARF001.BMP, SNARF002.BMP ... SNARF999.BMP. Both text and graphics can
be saved, but the saved image is always a graphic file, since a text
screen is converted to its color graphic image. Most images are saved in
a second or two, but some can take up to 30 seconds to save.

At least an 80386 CPU running DOS 2.0 is required. Any PC made in the
last 20 years can easily handle the task.

Because Alt+S might be used by the program you want to take a snapshot
of, other hotkeys can be specified. When Snarf is first run, if a number
is added to the command line, it will change the scan code used for the
hotkey. For example, to change the hotkey to Alt+C type: "snarf 46". The
number is in decimal, not hex. A list of scan codes is provided in
SCANCODE.TXT. After Snarf has been installed, the hotkey cannot be
changed by attempting to reinstall Snarf.

If a second number is added to the command line, a timer is set that
takes a snapshot when it times out. For example, "snarf 0 15" takes a
snapshot 15 seconds after Snarf is installed. The 0 indicates the default
hotkey (Alt+S) is used. The timer is particularly useful for some game
programs that take complete control of the keyboard, which prevents Snarf
from receiving its hotkey.

If a captured image file can't be written to the same directory as the
program being run, for instance if it's on a CDROM, then use a path name
to start the program. For example, from a directory on a C drive where
you want to save image files, type D:\pathname\yourprog


KNOWN PROBLEMS

Some games use an alternative display mode, called Mode-X, which is not
supported by Snarf.

Under Windows XP, Snarf prevents the use of long file names. This is a
problem with any TSR running under the Windows NT family. The problem is
related to the fact that the 32-bit CMD is switched to a 16-bit Command
without any warning or indication.

Also under Windows XP, DOSKEY quits working after Snarf (or any TSR) is
installed. For example, the up-arrow key will no longer select previous
commands. Reinstalling DOSKEY doesn't solve the problem.


ERROR MESSAGES

If Snarf detects an error, it beeps three times, blanks the screen and
displays a message. Although your original screen image is gone, your
program is still running. After noting the error message, type a command
to try to refresh the screen. If you were at a DOS prompt, a new prompt
will appear when you press the Enter key.

Error: 1 mmm indicates an unsupported display mode. The mode is the
second number (mmm). Snarf supports all available VGA and VESA modes.

Error: 2 indicates an attempt to save more than 999 image files in the
current directory.

Error: 3 xxx indicates that the output file couldn't be written to disk.
The DOS error code is the second number (xxx), which shows the reason.
Common DOS error codes are 3: diskette not inserted into the drive; and
5: write-protected diskette. Another possible error is that the root
directory is full.

Error: 4 indicates insufficient disk space to save the image file.


USE AT YOUR OWN RISK

Snarf has been used successfully for over a dozen years on many different
computers, but it's a complex program that might not work on all PCs for
all programs. If you find a problem, I'd really like to know about it.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License version 2 as published
by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program (in the file LICENSE.TXT); if not, write to the Free
Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


Thanks for your interest in Snarf.

Loren Blaney
loren.blaney@gmail.com
