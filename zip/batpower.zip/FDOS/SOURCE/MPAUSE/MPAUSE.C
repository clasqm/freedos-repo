/***********************************************************

   MPAUSE.C  -  Wait for button press, OR keystroke, then quit.

***********************************************************/

#include <dos.h>
#include <conio.h>
#include "getsmall.h"

#define MOUSE 0x33

int chkdrv(void);                 /*  Checks if driver installed */

union REGS inregs, outregs;        /*  Structures to contain      */
struct SREGS segregs;              /*  register values for int86x */

void main(void)
{
    if (chkdrv())
        {
        cputs("Press any key or mouse button to continue . . . ");
        inregs.x.ax = 0;    /* Function 0:  Mouse Reset */
        int86x(MOUSE, &inregs, &outregs, &segregs);
        do
            {
            inregs.x.ax = 3;  /* Function 3:  Get Button Status (and Position) */
            int86x(MOUSE, &inregs, &outregs, &segregs);
            } while ((!outregs.x.bx) && (!kbhit()));
        }
    else
        {
        cputs("Press any key to continue . . . ");
        while (!kbhit());
        }
    while (kbhit()) getch(); /* flush kb buffer */
}

int chkdrv ()
{
    unsigned long address;
    unsigned char first_byte;

    inregs.x.ax = 0x3533;          /* Get interrupt vector for 0x33 */
    intdosx ( &inregs, &outregs, &segregs);
    address = (((long) segregs.es) << 16) + (long) outregs.x.bx ;
    first_byte = (unsigned char) * (long far *) address;

    /* Be sure vector isn't 0 and first instruction isn't iret */
    if ((address == 0L) || (first_byte == 0xCF))
        return 0;
    else
        return 1;
}
