/*
     Program: AllocMem (Allocate Memory)
     Version: 1.00
     Date:    September 11, 1987

     Tests the memory allocation/deallocation routines of a C compiler.
*/
char *malloc();

main()
     {
     char *x;
     unsigned i;

     for (i = 0; i < 50000; ++i)
          {
          x = malloc(10000);
          free(x);
          }
     }
