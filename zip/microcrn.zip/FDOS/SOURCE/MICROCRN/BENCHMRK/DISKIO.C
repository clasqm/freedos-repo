/*
     Program: DiskIO
     Version: 1.00
     Date:    September 11, 1987

     Tests the speed of disk i/o library routines.
*/

#include <stdio.h>

main()
     {
     int i, j;
     FILE *f;
     char buf[100];

     f = fopen("diskio.tst","w+");

     for (i = 0; i < 1000; ++i)
          {
          for (j = 0; j < 78; ++j)
               {
               fputc('.',f);
               }
          fprintf(f," end line #%d\n",i);
          }

     fclose(f);

     f = fopen("diskio.tst","r+");

     for (i = 0; i < 1000; ++i)
          {
          fgets(buf,100,f);
          }

     fclose(f);
     }
