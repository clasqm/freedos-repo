/*
     Program: Crunch
     Version: 1.00
     Date:    September 10, 1987

     Tests the number crunching capabilities of a C Compiler.
*/
#include <stdio.h>
#include <math.h>

main()
     {
     double a, b, c, r1, r2, x;

     x = 1000.0;

     for (a = 0.01; a < 1; a = a + 0.01)
          {
          r1 = tan(exp(log(1.0/a)));
          r2 = sqrt(fabs(r1)) * cos(1/r1);
          b = r1 * r2 + 1.0 / a;
          c = b * a / (r1 - r2);
          x = x * (sqrt(fabs(b))) / (sqrt(fabs(b)));
          x = ((x + c - r1) / r2) * r2 - c + r1;
          }

     printf("x = %lf\n",x);
     }
