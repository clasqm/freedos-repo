/*
     Program: Bench3
     Version: 1.00
     Date:    September 10, 1987

     General C Benchmark test #3
*/
#include <stdio.h>

main()
     {
     int i;

     for (i = 0; i < 200; ++i)
          printf("#%3d -- This is a test string from the program %s. %6.2f\n",i,"Display",1234.5678);
     }
