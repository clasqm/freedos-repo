/*
     Program: Sort
     Version: 1.00
     Date:    September 12, 1987

     Sort a reverse order array of numbers using QuickSort. A general test
     for C compilers.
*/

#define MAXITEMS 20000

int test[MAXITEMS];

void quicksort(int *,int);
void qs(int *,int,int);

main()
     {
     int i, j;

     for (i = 0; i < MAXITEMS; ++i)
          test[i] = MAXITEMS - i - 1;

     quicksort(test,MAXITEMS);
     }

void quicksort(item,count)
int *item;
int count;
     {
     qs(item,0,count-1);
     }

void qs(item,left,right)
int *item;
int left, right;
     {
     register int i, j;
     int x, y;

     i = left;
     j = right;
     x = item[(i+j)/2];

     do
          {
          while (item[i] < x && i < right) i++;
          while (x < item[j] && j > left)  j--;
          if (i <= j)
               {
               y = item[i];
               item[i] = item[j];
               item[j] = y;
               i++;
               j--;
               }
          }
     while (i <= j);

     if (left < j)  qs(item,left,j);
     if (i < right) qs(item,i,right);
     }
