/*
     Program: CallOver (Call Overhead)
     Version: 1.00
     Date:    September 10, 1987

     Tests fucntion call overhead for C Compilers
*/

main()
     {
     unsigned i;

     for (i = 0; i < 50000; ++i);

     printf("\n%d i\n",i);
     }
