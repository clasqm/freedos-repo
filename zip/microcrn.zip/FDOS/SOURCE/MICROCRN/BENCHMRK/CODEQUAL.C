/*
    Program: CodeQual (Code Quality)

    Version: 1.00
    Date:    September 22, 1987

    Language: Generic ANSI C

    This program should be disassembled after a compile to show how
    "intelligently" the compiler generates object code.

    Copyright 1987 Scott Robert Ladd.
    Source code released into the public domain.
*/

#include "stdio.h"

main()
     {
     register int i, j;
     int k = 2048, l = 0;

     for (i = 0; i < 2; ++i)
          {
          for (j = 0; j < 3; ++j)
               {
               putchar('.');
               k = k * 4;
               l = l + i * j;
               }
          }
     }
