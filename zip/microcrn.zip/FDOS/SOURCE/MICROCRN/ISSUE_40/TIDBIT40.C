/* Code from Tidbits column in Micro Cornucopia Issue #40  (two listings) */

/* listing 1 -- 2 pass standard deviation algorithm
             explicitly declaring register variables */

#include <stdio.h>

void stat(double *list);

main()
{
        register short i,j;
        double list[7000];

        for(i = 0; i < 6999; i++)
        list[i]=i + 1;
        stat(list);
}
void stat(double *list)
{
        register i,c;
        double x,z,dev,square,squares,var,sd;
        double sqrt(double sd);
        x = squares = 0;
        puts("start");
        for(i = 0; i < 6999; i++){
                x = list[i] + x;
                }
        z = x/i;
        printf("%f\n",z);
        for(i = 0; i < 7000; i++){
                dev = z - list[i];
                square = dev * dev;
                squares = squares + square;
                }
        var = squares/(i-1);
        printf("%f\n",var);
        sd = sqrt(var);
        printf("%f\n",sd);
}

/* listing 2 -- lemma (one pass) algorithm */

#include <stdio.h>

void stat(double *list);

main()
{
        double list[7000];
        int i;

        for(i = 0; i < 6999; i++)
                list[i]=i + 1;
        stat(list);
}
void stat(double *list)
{       int i,c;
        double x,z,dev,square,squares,var,sd;
        double sqrt(double sd);
        x = squares = 0;
        puts("start");
        for(i = 0; i < 6999; i++){
                x += list[i];
                squares += list[i] * list[i];
                }
        z = x/i;
        printf("%f\n",z);

        var = (squares - (x * x)/i)/ (i - 1);
        printf("%f\n",var);
        sd = sqrt(var);
        printf("%f\n",sd);
}
