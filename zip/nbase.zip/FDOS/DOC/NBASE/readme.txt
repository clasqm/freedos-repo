          nB (nano Base) 97.01


          Copyright (c) 1996-1997  Daniele Giacomini

          This program is  free software;  you can  redistribute it  and/or
          modify it under the  terms of the GNU  General Public License  as
          published by the  Free Software Foundation;  either version 2  of
          the License, or (at your option) any later version.

          This program is distributed in the  hope that it will be  useful,
          but WITHOUT ANY  WARRANTY; without even  the implied warranty  of
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the  GNU
          General Public License for more details.

          You should have received a copy of the GNU General Public License
          along with  this program;  if not,  write  to the  Free  Software
          Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

          Send your  comments, suggestions,  bug reports  and english  text
          corrections to:

          Daniele Giacomini
          Via Turati, 15
          I-31100 Treviso
          Italy

          daniele@tv.shineline.it



          First of all, I am sorry for my bad English.

          nB ("nano Base": "n"  = "nano" = 10**(-9)  = "very little") is  a
          little DOS  xBase written  in CA-Clipper  5.2  that can  help  to
          access .DBF file created with different standards. nB can  access
          files created with Fox Pro 2, dBASE IV, dBASE III, dBASE III PLUS
          and CA-Clipper.

          nB is:

          *    a dot command interpreter,

          *    a menu driven xBase,

          *    a xBase program interpreter,

          nB may be useful because:

          *    it is Freeware and contains the source code;

          *    it is a all in one utility;

          *    with nB, a  commercial compiler is  no more  needed to  make
               simple programs:

               *    it can  compile some  simple  xBase programs  and  then
                    execute them,

               *    may functions  are  added to  the  standard  CA-Clipper
                    language.

          nB is compiled in  two versions: a  small one to  be used on  old
          computers, tipically x86 with  640K ram, and a  second one to  be
          used on better computers, at least 286 (or better) with 2M ram.

          nB is composed from  the following files, where  "xx" is the  the

          version code.

          NBASExx1.ZIP   EXEs for small PCs
          NBASExx2.ZIP   Runtime EXEs for small PCs
          NBASExx3.ZIP   EXEs for 286 with 2M+
          NBASExx4.ZIP   DOCs
          NBASExx5.ZIP   EXAMPLEs
          NBASExx6.ZIP   SRCs for version 96.06.16
          NBASExx7.ZIP   SRCs for the current version

          Every archive file contains:

          COPYING.TXT    GNU General Public Licence  version 2 in Dos  text
                         format.
          README.TXT     the readme file.
          FILE_ID.DIZ    definition.

          The file NBASExx1.ZIP contains also the following files.

          NB.EXE         the  executable  program  for  DBFNTX  and  DBFNDX
                         files, linked with RTLINK.
          NB.HLP         this manual in "Help Text File" format.

          The file NBASExx2.ZIP contains also the following files.

          NB.EXE         the run-time to execute macro programs for  DBFNTX
                         and DBFNDX files handling, linked with RTLINK.

          The file NBASExx3.ZIP contains also the following files.

          NB.EXE         the executable program for DBFCDX, DBFMDX,  DBFNDX
                         and DBFNTX files, linked with EXOSPACE.
          NB.HLP         this manual in "Help Text File" format.

          The file NBASExx4.ZIP contains also the following files.

          NB.PRN         this manual in printed text format.
          NB.RTF         this manual in RTF format.
          NB.TXT         this manual in ASCII text format.
          NB.HTM         this manual in HTML format.

          The file NBASExx5.ZIP contains also the following files.

          _ADDRESS.DBF   an example database file.
          _ADDRESS.NTX   index file associated to _ADDRESS.DBF.
          _ADDRESS.LBL   a label  form file  used to  print data  contained
                         inside _ADDRESS.DBF.
          _ADDRESS.FRM   a report form  file used to  print data  contained
                         inside _ADDRESS.DBF.
          _ADDRESS.RPT   a RPT  text  file  used to  print  data  contained
                         inside _ADDRESS.DBF.

          _MAINMNU.&     a macro  program source  example  of a  menu  that
                         executes some others macro programs. This  example
                         is made to demonstrate how nB can execute directly
                         a soruce code without  compiling it. This  example
                         is made only to taste it: it is very slow and only
                         a speady machine can give the idea of it.
          0MAINMNU.&     a macro  program source  example  of a  menu  that
                         executes some  others macro  programs. It  is  the
                         same as _MAINMNU.&  but it  is made  to start  the
                         execution of the compliled macros.
          0MAINMNU.NB    compiled macro program 0MAINMNU.&

          0MAINMNU.BAT   a batch file to show how  to run the execution  of

                         0MAINMNU.NB

          1ADDRESS.&     a macro program source example for handling a .DBF
                         file containig addresses in various ways.
          1ADDRESS.NB    compiled macro 1ADDRESS.&.

          2ADDRESS.&     a macro program source example for handling a .DBF
                         file containig addresses in various ways: a little
                         bit more complicated than 1ADDRESS.&.
          2ADDRESS.NB    compiled macro 2ADDRESS.&.

          3ADDRESS.&     a macro program source example for handling a .DBF
                         file containig addresses in various ways: a little
                         bit more complicated than 2ADDRESS.&.
          3ADDRESS.NB    compiled macro 3ADDRESS.&.

          4ADDRESS.&     a macro program source example for handling a .DBF
                         file containig addresses in various ways: a little
                         bit more complicated than 3ADDRESS.&.
          4ADDRESS.NB    compiled macro 4ADDRESS.&.

          ABIORITM.&     a macro program source example for calculating the
                         personal bio wave.
          ABIORITM.NB    compiled macro ABIORITM.&.

          _STUDENT.DBF   a  .DBF  file  used  inside  the  BSTUDENT   macro
                         example.
          _STUDENT.NTX   index file used for _STUDENT.DBF.
          _STUDSTD.DBF   a  .DBF  file  used  inside  the  BSTUDENT   macro
                         example.
          _STUDENT.RPT   a RPT  text  file  used to  print  data  contained
                         inside _STUDENT.DBF.

          _STUDSTD.RPT   a RPT  text  file  used to  print  data  contained
                         inside _STUDSTD.DBF.

          BSTUDENT.&     a  macro  program  source  example  for   students
                         evaluation:  a  description   about  students   is
                         obtained linking other standard descriptions.
          BSTUDENT.NB    compiled macro BSTUDENT.&.

          CBATMAKE.&     a macro program source example to generate a batch
                         file to be used to back up an entire hard disk.
          CBATMAKE.NB    compiled macro CBATMAKE.&.

          BROWSE.&       a  macro  program  source  example  to  start   an
                         automatic browse.
          BROWSE.NB      compiled macro BROWSE.&.
          BROWSE.BAT     batch file to start a .DBF browse with the  BROWSE
                         macro program.

          MENU.&         a macro program source example for a Dos menu.
          MENU.NB        compiled macro MENU.&.
          MENU.BAT       batch file to use the MENU macro.

          The file NBASExx6.ZIP contains  also the following files:  source
          code for the version 96.06.16.

          NB.PRG         the main source file for version 96.06.16.
          NB_REQ.PRG     the source file conatinig links to all the
                         standard functions.
          NB.LNK         link file for compilation.
          NB_NRMAL.RMK   rmake file to compile with RTLink.

          NB_EXOSP.RMK   rmake file to compile with Exospace.

          NB_RUNTI.RMK   rmake file to compile with RTLink defining RUNTIME
                         to obtain a small nB runtime version.
          MACRO.LNK      link file to compile and link a macro.
          MACRO.RMK      rmake file to compile and link a macro.

          The file NBASExx7.ZIP contains  also the following files:  source
          code for the current version.

          NB.PRG         the main source file.
          REQUEST.PRG    the source  file conatinig  links to  all the  CA-
                         Clipper functions.
          STANDARD.PRG   the source file for standard functions.
          EXTRA.PRG      the source file for other standard functions.
          STANDARD.CH    general include  file that  subtitues all  include
                         file   normally    used   for    normal    Clipper
                         compilations.
          NB.CH          include file specific for nB.
          NB.LNK         link file for compilation.
          NB_RUNTI.LNK   link file for runtime compilation.
          NB_NRMAL.RMK   rmake file to compile with RTLink.
          NB_EXOSP.RMK   rmake file to compile with Exospace.
          NB_RUNTI.RMK   rmake file to compile with RTLink defining RUNTIME
                         to obtain a small nB runtime version.
          MACRO.CH       include file to compile and link a macro.
          MACRO.LNK      link file to compile and link a macro.
          MACRO.RMK      rmake file to compile and link a macro.
          CLIPMOUSE.ZIP  a simple Freeware library for mouse support  under
                         Clipper (c) 1992 Martin Brousseau.



          nB normal syntax is:

          nB [<nB_parameters>] [<macro_filename>] [<macro_parameters>]

          To run nB, just type the word "NB" and press [Enter] to  execute.
          It will run in command mode, this means that it will look like an
          old xBASE command prompt.

          To run  the program  as a  macro interpreter,  type the  word  NB
          followed from  the macro  file name  with extention  (no  default
          extention is supposed). If parameters are given, after the  macro
          file name, these will be  available inside the public  variables:
          c_Par1, c_Par2, ..., c_Par9. c_Par0  will contain the macro  file
          name (see the macro file  BROWSE.&). nB will terminate  execution
          when the macro terminates.

          These parameters are available for nB:

          -c   Suppress the copyright notice. It  is usefull when using  nB
               for macro interpretation.

          -w   Suppress the "Wait-Wheel" if not desired. It is the  "Wheel"
               that appears  at top-left  when a  macro is  interpreted  or
               other long elaborarions are executed.

          -?   Shows a short help.



          nB macro "compilation" syntax is:

          nB -m <source_macro_filename> [<destination_macro_filename>]

          With   the    -m    parameter,   nB    "compiles"    the    ascii

          <source_macro_filename> into <destination_macro_filename>.



          nB shows a "status  line" at the  top of the  screen when the  nB
          command prompt  or  the menu  system  is active.  It  shows  some
          important informations.

          | |DBFNTX    ||*|  1|ADDRESS   |     1/     4|ADDRESS.NTX |
           |  |          |  |    |             |      |
           |  |          |  |    |             |      |
           |  |          |  |    |             |    Last record (7).
           |  |          |  |    |             |
           |  |          |  |    |           Record pointer position (6).
           |  |          |  |    |
           |  |          |  |   Active Alias (5).
           |  |          |  |
           |  |          |  Current Work Area (4)
           |  |          |
           |  |          Deleted record appearence (3)
           |  |
           |  Actual default database driver (2).
           |
           Macro recorder indicator (1).


          |     1/     4|ADDRESS.NTX |  1|ADDRESS   |
                          |             |   |
                          |             |   |
                          |             |  Order Tag Name (10)
                          |             |
                          |           Order number (9)
                          |
                         Order Bag name (8)

          (1)  This is  the place  for the  macro recorder  indicator.  The
               symbol used is "&".
               BLANK - means that the macro recorder is OFF;
               & blink - means that the macro recorder is ON;
               & - means that the macro recorder is PAUSED.

          (2)  The  name  of  the  default  database  driver.  It  is   not
               necessarily the database driver for the active Alias; it  is
               only the  database driver  that will  be used  for the  next
               open/create operation.

          (3)  An asterisk (*) at this position indicates that SET  DELETED
               is OFF. This  means that deleted  records are not  filtered.
               When a BLANK is  in this place, SET  DELETED is ON, so  that
               deleted records are filtered.

          (4)  The active work area number, that is, the area of the active
               Alias.

          (5)  The active  Alias name.  Note that  the  Alias name  is  not
               necessarily equal to the .DBF file name.

          (6)  The actual record pointer position for the active Alias.

          (7)  The number of records contained inside the active Alias.

          (8)  The Order Bag name; that is the index file name.

          (9)  The order number.

          (10) The order tag (name). When  DBFNTX database driver is  used,

               it correspond to the Order Bag name.



          Starting nB without parameters, the dot line appears.

          This is the  place where  commands in  form of  functions may  be
          written and executed like a old xBase.

          The functions written inside the  command line that don't  result
          in an error, are saved inside  a history list. This history  list
          may be recalled with [F2] and then the selected history line  may
          be reused (eventually  edited). Key  [up]/[down] may  be used  to
          scroll inside the history list without showing the all list  with
          [F2].

          [Enter] is used to tell nB to execute the written function.

          As the dot line is not an easy way to use such a program, a  menu
          is available pressing  [F10] or [Alt]+[M].  The [F10] key  starts
          the ASSIST() menu.  This menu may  be started  also entering  the
          name of the function: "ASSIST()".

          nB includes  a simple  built-in text  editor:  DOC(). It  may  be
          started from the  dot line entering  "DOT()". No  special key  is
          dedicated to start this function.


          What's new:

               Mouse support: many standard functions are rewritten.

               TB() is modified: now more parameter are available.

               Bidimensional arrays may  be directly edited  with ATB(),  a
               Tbrowse function for arrays.

               More functions are availables.

               Other minor changes.

               Other minor bug corrections.



          If you like the program, I will be happy to know it, for  example
          receiving a e-mail where you say something like:

                                     "I use nB".

          Will you tell me if you like this work?

          Comments, suggestions, bug reports  and english text  corrections
          are welcome (and needed) to make a better nB.

          Write to:                     Daniele Giacomini
                                        Via Turati, 15
                                        I-31100 Treviso
                                        Italy

          Send your e-mail to:          daniele@tv.shineline.it

          The latest about nB may be found at:
               http://www.geocities.com/SiliconValley/7737/nanobase.html


