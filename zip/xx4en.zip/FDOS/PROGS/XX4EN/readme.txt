-----------------------------------------------------------------------------
                 Access 4.60 Readme for general information
-----------------------------------------------------------------------------


CONTENTS
------
1. WHAT TO DO AFTER INSTALLATION
2. HINTS
3. PROBLEMS
4. MAKE CONTACT


1. WHAT TO DO AFTER INSTALLATION
================================

Access should be working immediately after you installed it.
However, it is wise to adjust your autoexec.bat accordingly:

- Add "C:\XX" to your PATH.
- Add the line "CALL C:\XX\XX.BAT" at the end.

The first adjustment makes it possible to start Access from anywhere on
your harddisk. And the second takes care of automatically starting Access
on boot-up.


2. HINTS
========

- Just as in the previous versions, Access supports a simple way
  to speed up the progress of putting a new program in its lists.
  If you add a new program only by entering its TITLE, Access itself
  will fill in the other fields, by looking at the title. Check it out!

- Pressing INS or DEL is another way to add or remove groups and programs.

- The QuickKey is a fast way to search for programs in Access. But a sort of
  QuickKey is also available when you are browsing through directories on
  your harddisk. Please try it out, you'll see the list jump to the letters
  you type.

- Access uses XMS memory to cache the icons. It speeds up displaying the icons
  enormously. However, Access needs 1MB min. to be able to cache them.

- You can use the mouse in several ways to scroll through lists. Pressing the
  arrows on the right is possible of course, but you can also click on the bar
  between them. Then move up and down to scroll through the list.

- Pressing on the cross in the upper left corner of a window closes it. It is
  equal to pressing [ESC].

- It is possible to add Windows icons to Access' icon-library!
  To do this, exit to DOS and type:

  ADDICO <FILE> [ENTER]

  <FILE> should be a standard Windows icon. Please don't forget to enter the
  file's full path, together with its extension(.ico).
  An example: ADDICO C:\WINDOWS\HELP.ICO [ENTER]
  Furthermore, a simple batchfile is also installed to add an entire
  directory of icons to the lib. Its syntax: ADDALL <DIR>
  I think that adding icons to Access' library will be built in, in the future.

- You can use XXSETUP.EXE to reconfigure Access. For example, if you ever want
  to change the CD-ROM drive for playing audio-CD's.

- It is sensible to place/move programs you use frequently, on top of Access'
  lists. The QuickKey will do it's job better then.

- You can change the contents of Access' screensaver. The file SSAVER.XX is
  a simple textfile you can edit. But remember not to make the lines to long,
  or they won't fit on the screen! Have fun:)

- It's a very good thing to make backups of Access regularly. Especially if
  Access lists are filling up.
  Unfortunately, every program contains bugs, and Access is most probably
  no exception. If you ever have to fill in all your programs again...

- New: A simple program named showpcx that you may use in the file xx.bat
  to show an intro-screen, whenever you start Access. Its syntax:

  showpcx <FILE> <SECONDS>

  For example: to show the file csi.pcx for 2 seconds before starting
  Access, you have to insert the following line in xx.bat, between
  the second and third line ("ENTERDIR" and ":BEGIN") :

  showpcx csi.pcx 2

3. PROBLEMS
===========

INSTALLING OVER OLDER ACCESS VERSION
You can only install this version in C:\XX
If you've been using version 3.xx, the installer will safely convert the
data to this new version 4.60
Installing over version 2.xx is only possible with the 3.xx installer.
Anyway, this installer will always store your old version safely, so
no data will be lost.


PROBLEMS WITH INSTALLING ACCESS
Try a step-by-step installation, so you can see where the problem arises.
If you can't fix the problem yourself, you can contact me for advice.


PROBLEM WITH THE CACHE OPTION
Using the cache option to speed-up programs that require a lot of
disk-accessing is one of the fine things of Access. But then again, only
if it really works! If you get a error message (when you enable the use of
cache), you should do the following:

- Start an editor(edit.com) to edit the file XXCACHE.BAT
  This file switches the cache on. Make sure it starts a correct cache program.
  If you happen to have Symantec's SPEEDRIVE for example, it should contain:

  C:\SPEEDRV\SPEEDRV /INSTALL /EXT=3072,3072

  Don't forget to enter the complete path to the cache program, or else it
  won't be working.

- Also edit the file XXFLUSH.BAT
  This file does the opposite; it disables the cache program, and flushes all
  data back to the hardddisk. An example:

  C:\SPEEDRV\SPEEDRV /UNINSTALL

  It is also possible to use Microsoft's SMARTDRV, but unfortunately this
  program hasn't got the ability to remove itself from memory. However,
  if you still want to use it, you can enter:

  XXCACHE.BAT->  C:\DOS\SMARTDRV
  XXFLUSH.BAT->  C:\DOS\SMARTDRV /C 

  Although smartdrive will be active all of the time now, the cache will at
  least be flushed every time you get back in Access.


4. MAKE CONTACT
==================

For questions, suggestions, bugs or a chat:

		Ronald Blankendaal
		1703 PZ
		Poldermolen 40  Heerhugowaard
		The Netherlands
		Tel.: (+31) - 72 - 574 5884
		Fax : (+31) - 226 - 45 3624
		E-Mail: r.blankendaal@quicknet.nl

Updates, information and more software can be found on
"The Official Access Homepage" on the Internet: 

		http://surf.to/AccessDosMenu

And remember: Access is FREEWARE. You can freely copy Access' installation
version to your friends and acquaintances.
