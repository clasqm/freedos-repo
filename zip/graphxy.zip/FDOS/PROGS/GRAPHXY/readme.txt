~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Version: 1.0           	   GraphXY              Date: January 21, 1999
                           ^^^^^^^                                
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Welcome to GraphXY, the only graphing calculator that is FREE. 
GraphXY functions as a graphing calculator. It is very useful for high
school students in their math classes as well as for anybody who wants
to have some fun graphing equations. This program includes many
features. First, it has smart equation entering where you don't have
to insert any special characters, just type the equation as you would
write it on paper. Also, you can view the plotting points and roots of
equations. You can zoom in or out and graph several equations on one 
graph. The quick help box on the bottom of the screen guides you 
through every step you need to make to use GraphXY to its fullest 
extent. It makes easy for you to work with this program. 
Thanks for using my program.

 
              For any updates please visit my site at:
                      http://come.to/yevgeniy

SPECIAL NOTE
 IT IS RECOMMENDED THAT YOU RUN THIS PROGRAM UNDER MS-DOS.
 WHEN YOU RUN THIS GRAPHXY UNDER WINDOWS THE PROGRAM CAN APPEAR IN MS-DOS
 WINDOW. MAKE SURE THAT YOU RUN THIS PROGRAM IN FULL-SCREEN MODE.
 IF THE PROGRAM APPERS IN MS-DOS WINDOW LOCATE THE FULL-SCREEN BUTTON
 ON TOP OF THE WINDOW AND CLICK IT.

LICENCE AGREEMENT
  1)GraphXY is a FREEWARE. 
    You may freely copy and distribute the package only in the 
    unmodified "zipped" file (graphxy.zip). 
  
  2)You are prohibited from charging a fee or requesting donations 
    for the package, distributing/including the package in commercial
    products, and modifying the package. 
    It is ONLY allowed to the author.
 
  3)GraphXY is provided as is, without warranty of any kind.
   The author shall not be liable for damages of any kind.  Use of 
   this software indicates you agree to this.
 
Author: Yevgeniy Eltsufin
E-mail: orsk@homail.com
ICQ#: 15523811