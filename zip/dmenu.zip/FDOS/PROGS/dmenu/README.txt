DMenu v1.0
====================================
DMenu is a small graphical menu program. It is limited to 10 categories with 10 items in each.
To create a menu, simply call "menugen.exe".

For most games and programs, you will have to create a batch file to cd into their install directories.
Example:

set2.bat
--------
cd c:\settlers
s2.exe

To start, please run
dmenu.bat