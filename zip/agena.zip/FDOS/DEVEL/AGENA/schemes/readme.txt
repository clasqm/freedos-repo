Agena language scheme files
---------------------------

agena.lang       - mimetype language description
agena.xml        - scheme file for jEdit
agena.sch        - scheme file for Proton 3
nedit.rc         - scheme file for nedit 5.5
nedit.rc.solaris - scheme file for nedit 5.5 for Solaris, rename to nedit.rc