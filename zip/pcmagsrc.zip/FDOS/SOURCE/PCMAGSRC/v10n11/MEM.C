/* 
MEM.C -- How much memory can we allocate under MS-DOS?

Microsoft C: cl -AL mem.c
Turbo C:     tcc -ml mem.c

Copyright (c) 1991 Ziff Communications Co.
    PC Magazine * Andrew Schulman
*/

#include <stdlib.h>
#include <stdio.h>

#define SIZE    10240

main()
{
    unsigned long bytes = 0;
    char *p;
    
    while (p = malloc(SIZE))
    {
        *p = 'x';
        p[SIZE-1] = 'y';
        bytes += SIZE;
    }
    
    printf("Allocated %lu bytes\n", bytes);
    printf("Press ENTER to release memory...");
    getchar();
    return 0;
}
