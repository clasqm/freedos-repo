/* STRREV.C
   STRREV.BIN source, compile/link with:
   TCC -mc -c strrev                 : memory model MUST BE compact,
   TLINK /i strrev,,,D:\TC\LIB\CC    : data is far, use dBIV's stack
                                     : assuming CC.LIB is in D:\TC\LIB\
   EXE2BIN strrev                    : creates STRREV.BIN
   DEL strrev.obj
   DEL strrev.exe

   to use from dBASE:
   .LOAD strrev
   .m="whatever"
   .CALL strrev WITH m
   * m will be reversed
*/

#include <dos.h>                                     /* for MK_FP() */
#include <string.h>
void far main(void)
{
   char *param;                       /* compact model forces "far" */

   if (_DS == 0)                         /* if no parameters passed */
      return;                                             /* return */

   param = MK_FP(_DS,_BX);          /* address the passed parameter */

   strrev(param);                           /* call library routine */
   return;
}

