
		name	hello
_text	segment	byte public 'code'
dgroup	group	_data,_bss
		assume	cs:_text,ds:dgroup,ss:dgroup
_text	ends
_data	segment word public 'data'
_d@		label	byte
_data	ends
_bss		segment word public 'bss'
_b@		label	byte
_bss		ends
_text	segment	byte public 'code'
; /*	HELLO.C -- Hello, world */
; 
; #include <stdio.h>
; 
; main()
; {
_main	proc	near
; 	printf("Hello, world\n");
	mov	ax,offset _s@
	push	ax
	call	near ptr _printf
	pop	cx
; }
@1:
	ret	
_main	endp
_text	ends
_data	segment word public 'data'
_s@		label	byte
	db	72
	db	101
	db	108
	db	108
	db	111
	db	44
	db	32
	db	119
	db	111
	db	114
	db	108
	db	100
	db	10
	db	0
_data	ends
_text	segment	byte public 'code'
	extrn	_printf:near
	public	_main
_text	ends
	end

