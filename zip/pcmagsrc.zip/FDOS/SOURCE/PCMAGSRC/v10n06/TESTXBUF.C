// testxbuf.C - demonstrates use of XBUF buffer
//
// Use C>TESTXBUF to run without extended buffering
// Use C>TESTXBUF 1 to run *with* extended buffering

#include<conio.H>
#include<dos.H>
#include<stdio.H>
#include"xbuf.H"

void main(int argc, char **argv)
    {
    int key, XBUF = 0;

    if(argc > 1)
        XBUF = 1;
    if(XBUF)
        xbuf_install(DEFAULT_SIZE);
    sleep(5);  // Wait 5 seconds

    if(XBUF)
        while(iskey())
            {
            key = getkey();
            printf((key > 31 && key < 128) ? "%c " : "%x ", key);
            }
    else
        while(kbhit())
            {
            key = getch();
            if(!key)
                key = getch() << 8;
            printf((key > 31 && key < 128) ? "%c " : "%x ", key);
            }
    if(XBUF)
        xbuf_remove();
    }
