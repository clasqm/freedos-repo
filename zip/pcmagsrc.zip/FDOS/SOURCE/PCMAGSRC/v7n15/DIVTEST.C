/* divtest.c RHS 5/18/88
 *
 * This program reports the time to execute a loop with a long divide
 * operation in it.
 *
 *   To compile for MSC 5.x:
 *        cl /W3 /Od divtest.c
 */
 
#define ITERATIONS 100000L
#define DIVIDEND    1000L
#include<time.h>
#include<stdio.h>
 
void main(void);              /* function prototype */
 
void main(void)
{
     long i,start,end,temp;
     float loop,expr;
 
     start = clock();
 
     for( i = 0L; i < ITERATIONS; i++)  /* time the operation    */
          temp = (i/DIVIDEND);          /* divide is tested here */
 
     end = clock();
 
     expr = (float)(end-start);
 
     expr /= CLK_TCK;
 
     printf("\nLoop with Operation time = %04.04f seconds",expr);
 
     start = clock();
 
     for( i = 0L; i < ITERATIONS; i++); /* time the loop alone */
          temp = i;
 
     end = clock();
 
     loop = (float)(end-start);
     loop /= CLK_TCK;
 
     printf("\nLoop                time = %04.04f seconds",loop);
 
     printf("\n\nOperation Overhead       = %04.04f seconds",expr-loop);
}
