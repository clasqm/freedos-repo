/*
        MODENV.C    Demonstration of C "putenv" function.
        Copyright (C) 1987 Ziff Communications Co, by Ray Duncan
*/

#include <stdio.h>
#include <process.h>

main(argc,argv,envp)
int argc;
char *argv[];
char *envp[];
{   char comspec[80];           /* COMSPEC= value goes here */
    int status;                 /* scratch storage */

                                /* get location of COMMAND.COM from
                                   environment COMSPEC= variable */
    strcpy( comspec, getenv("COMSPEC") );
    if( comspec[0] == NULL )
        {   puts("\nNo COMSPEC found in environment.");
            exit(1);
        }
                                /* change PROMPT= environment variable */
    if( putenv("PROMPT=Enter EXIT to Return to MODENV$_$p$g") )
        puts("\nCall to PUTENV failed.");
    
                                /* announce launch of COMMAND.COM */
    puts("\nNow spawning a new copy of COMMAND.COM.");

                                /* now spawn new command processor */
    if( spawnle(P_WAIT,comspec,comspec,NULL,envp) == -1 )
        puts("\nEXEC of COMMAND.COM failed");

                                /* announce return from COMMAND.COM */
    puts("\nBack from new COMMAND.COM, MODENV is exiting.");

    exit(0);                    /* now terminate */
}
