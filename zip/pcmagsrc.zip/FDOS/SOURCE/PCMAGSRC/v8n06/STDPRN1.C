/* create stdprn for Turbo C
 * version 1
 */
#include<stdio.h>

main()
{
	FILE	*stdprn;

	if(!(stdprn = fopen("LPT1","wt")))
	{
		fprintf(stderr,"\nUnable to open stdprn");
		exit(0);
	}
	fprintf(stdprn,"stdprn is open\f");
}

