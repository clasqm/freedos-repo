void quicksort(int left, int right)
{
    int i, j, t;                    /* some scratch variables */

    if(right > left)                /* skip unnecessary calls */
    {   
        i = left-1; j = right;      /* initialize scan pointers */

                                    /* partition array on value */
                                    /* of the rightmost item */
        do {
                                    /* scan right for item >=  */
                                    /* than partitioning value */
            do i++; 
                while(items[i] < items[right]);

                                    /* scan left for item <=   */
                                    /* than partitioning value */
            do j--; 
                while(items[j] > items[right] && j > 0); 

            t = items[i];           /* interchange the items */
            items[i] = items[j];
            items[j] = t;

        } while(j > i);             /* do until pointers cross */

        items[j] = items[i];        /* undo the last swap and */
        items[i] = items[right];    /* put the partitioning */
        items[right] = t;           /* element into position */

        quicksort(left, i-1);       /* sort items to left of */
                                    /* partitioning element */

        quicksort(i+1, right);      /* sort items to right of */
    }                               /* partitioning element */
}
