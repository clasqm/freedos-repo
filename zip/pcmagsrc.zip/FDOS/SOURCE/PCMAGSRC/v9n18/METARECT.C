/*----------------------------------------------------------
   METARECT.C -- A function to obtain a metafile image size
                 (c) Ziff Communications Co, 1990
                 PC Magazine * Charles Petzold, 7/90
  ----------------------------------------------------------*/

VOID QueryMetaFileBoundaryRect (HAB hab, HMF hmf, RECTL *prcl)
     {
     HPS   hps ;
     SIZEL sizlPage ;

     sizlPage.cx = 100 ;
     sizlPage.cy = 100 ;

     hps = GpiCreatePS (hab, NULL, &sizlPage, PU_ARBITRARY) ;

     GpiSetDrawControl (hps, DCTL_DISPLAY, DCTL_OFF) ;
     GpiSetDrawControl (hps, DCTL_BOUNDARY, DCTL_ON) ;

     GpiPlayMetaFile (hps, hmf, 0L, NULL, NULL, 0L, NULL) ;

     GpiSetDrawControl (hps, DCTL_DISPLAY, DCTL_ON) ;
     GpiSetDrawControl (hps, DCTL_BOUNDARY, DCTL_OFF) ;

     GpiQueryBoundaryData (hps, prcl) ;

     GpiDestroyPS (hps) ;
     }
