
HBITMAP GrayBit (HDC hdc)
     {
     static BYTE bData[8] = { 0x01, 0x23, 0x45, 0x67,
                              0x89, 0xAB, 0xCD, 0xEF } ;
     BITMAPINFO  *pbmi ;
     HBITMAP     hBitmap ;
     int         i ;

               // Allocate memory for the BITMAPINFO structure

     pbmi = malloc (sizeof (BITMAPINFOHEADER) + 16 * sizeof (RGBQUAD)) ;

     if (pbmi == NULL)
          return NULL ;

               // Initialize it for a 16-color 1-row by 16-column bitmap

     pbmi->bmiHeader.biSize          = sizeof (BITMAPINFOHEADER) ;
     pbmi->bmiHeader.biWidth         = 16 ;
     pbmi->bmiHeader.biHeight        = 1 ;
     pbmi->bmiHeader.biPlanes        = 1 ;
     pbmi->bmiHeader.biBitCount      = 4 ;
     pbmi->bmiHeader.biCompression   = BI_RGB ;  // no compression
     pbmi->bmiHeader.biSizeImage     = 0 ;
     pbmi->bmiHeader.biXPelsPerMeter = 0 ;
     pbmi->bmiHeader.biYPelsPerMeter = 0 ;
     pbmi->bmiHeader.biClrUsed       = 0 ;
     pbmi->bmiHeader.biClrImportant  = 0 ;

               // Initialize the color table for 16 gray shades

     for (i = 0 ; i < 16 ; i++)
          {
          pbmi->bmiColors[i].rgbBlue     = (BYTE) (16 * i) ;
          pbmi->bmiColors[i].rgbGreen    = (BYTE) (16 * i) ;
          pbmi->bmiColors[i].rgbRed      = (BYTE) (16 * i) ;
          pbmi->bmiColors[i].rgbReserved = 0 ;
          }
               // Create the bitmap

     hBitmap = CreateDIBitmap (hdc, &pbmi->bmiHeader, CBM_INIT,
                               bData, pbmi, DIB_RGB_COLORS) ;
               // Clean up

     free (pbmi) ;
     return hBitmap ;
     }


