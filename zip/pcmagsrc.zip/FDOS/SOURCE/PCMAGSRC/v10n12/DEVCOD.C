    ListOfLists far *doslist;
    DeviceDriver far *dd;
    // ...
    dd = &doslist->nul;
    for (;;)
    {
        printf("%Fp\t", dd);    
        if (dd->attr & CHAR_DEV)
            printf("%.8Fs\n", dd->u.name); 
        else
            printf("Block dev: %u unit(s)\n", dd->u.blk_cnt);
        dd = dd->next;
        if (FP_OFF(dd->next) == -1)
            break;
    }
