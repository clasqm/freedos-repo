/* WS4XLATE.C
    To compile: cl ws4xlate.c
    or          tcc ws4xlate
*/

#include<stdio.h>
#define LEADIN      0x1b            /* Esc lead in */
#define LEADOUT     0x1c            /* Esc lead out */
#define EXTENDED    0x80            /* extended char mask: 10000000 */

void main ()
{
    int c;

    while( (c = getchar()) != EOF)  /* get characters from input */
    {
        if(c & EXTENDED)            /* if high bit is set    */
        {                           /* embed it in escape chars */
            putchar(LEADIN);
            putchar(c);
            putchar(LEADOUT);
        }
        else                        
            putchar(c);             /* put to output             */
    }
}
