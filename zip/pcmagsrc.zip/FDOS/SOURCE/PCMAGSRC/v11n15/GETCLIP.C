/* GETCLIP.C -- get text from Windows clipboard */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "winclip.h"

void fail(char *s) { puts(s); exit(1); }

int main(void)
{
    char *s;
    
    if (! WindowsClipboard())
         fail("This program must run in a DOS box "
	      "under Enhanced mode Windows");

    if (s = GetClipString())
    {
        puts(s);
        FreeClipString(s);
    }
    else
        puts("* clipboard empty *");
    return 0;
}

