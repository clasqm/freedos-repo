// model.c RHS 3/4/91

#include"model_s.h"

void main(void)
    {
    char *model =
#if defined(__TINY__)
        "Tiny"
#elif defined(__SMALL__)
        "Small"
#elif defined(__COMPACT__)
        "Compact"
#elif defined(__MEDIUM__)
        "Medium"
#elif defined(__LARGE__)
        "Large"
#elif defined(__HUGE__)
        "Huge"
#endif
        ;

    printf("Compiled via the"
           " %s memory model!",
           model);
    }
