// getmaxx.c RHS 3/4/91

#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>

#define MAXDRIVERS    3
int graphdrivers[MAXDRIVERS] = { CGA, EGA, VGA };
char *graphdrivernames[MAXDRIVERS] = { "CGA", "EGA", "VGA" };

void main(void)
    {
    int graphmode = 0, i, j, low, high, err;
    int midx, midy, texth;
    char xrange[80], yrange[80], drivername[80];


    for(i = 0; i < MAXDRIVERS; i++)
        {
        initgraph(&graphdrivers[i], &graphmode, "");

        if(err = graphresult())
            {
            printf("Graphics error: %s\n",grapherrormsg(err));
            printf("Press any key to exit program...");
            getch();
            restorecrtmode();
            exit(1);
            }

        getmoderange(graphdrivers[i],&low,&high);

        for( j = 0; j < 2; low = high, j++)
            {
            setgraphmode(low);
            midx = getmaxx() / 2;
            midy = getmaxy() / 2;

            sprintf(drivername,"%s, mode:%s number:%d",
                graphdrivernames[i],
                getmodename(getgraphmode()),
                getgraphmode());
            sprintf(xrange,"X values range from 0 to %d",getmaxx());
            sprintf(yrange,"Y values range from 0 to %d",getmaxy());

            settextjustify(CENTER_TEXT,CENTER_TEXT);
            texth = textheight("W");
            outtextxy(midx,midy,drivername);
            outtextxy(midx,(midy += texth),xrange);
            outtextxy(midx,(midy += texth),yrange);
            getch();
            }

        closegraph();
        }
    exit(0);
    }
