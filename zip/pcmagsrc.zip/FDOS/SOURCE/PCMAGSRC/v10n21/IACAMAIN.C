IACAMAIN.C


/* IACAMAIN.C
  Demonstrate the use of the Intra-Application Communication Area (IACA)
*/

#include<process.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<malloc.h>
#include"iaca.h"

void main(void);

#define BUFFER_SIZE     20

void main(void)
        {
        char *message_buffer;

        if((message_buffer = malloc(BUFFER_SIZE)) == NULL)
                {
                puts("\nError! Unable to allocate memory.");
                exit(-1);
                }

                // Store return buffer address in first 4 bytes of the IACA
    _Iaca[0] = (void far *)message_buffer;
    printf("IacaMain: message_buffer set to %Fp...running child...\n",
        (void far *)message_buffer);

        if(spawnl(P_WAIT,"IACACHLD.EXE",NULL) == -1)
                {
                puts("\nError! Unable to locate IACACHLD.EXE.");
                exit(-1);
                }
        printf("IacaMain: message from child is \'%s\'\n",message_buffer);
    free(message_buffer);
        }



