IACACHLD.C

/* IACACHLD.C - IACAMAIN's child program */

#include<string.h>
#include<stdio.h>
#include"iaca.h"

void main(void);

void main(void)
        {
        char far *ptr;

        ptr = _Iaca[0];
    printf("IacaChld: ptr is set to %04Fp...placing message there.\n",ptr);
        _fstrcpy(ptr,"Hello from IACACHLD");
        }



�MDUL��MDNM�