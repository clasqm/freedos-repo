#include <extend.h>

CLIPPER stod( void )
{
   _retds( _parc( 1 ) );
}