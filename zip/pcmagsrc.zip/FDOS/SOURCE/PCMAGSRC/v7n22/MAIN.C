main()
{
	int i,j;

	Init_scrptr();

	for( i = j = 0; i < 24; i++, j++)
		qwrite(i,j,0x7, "This is normal video ");
	getch();
	for( i = j = 0; i < 24; i++, j++)
		qwrite(i,j,0x70,"This is reverse video");
	getch();
	for( i = j = 0; i < 24; i++, j++)
		qwrite(i,j,0x7, "This is normal video ");

}

