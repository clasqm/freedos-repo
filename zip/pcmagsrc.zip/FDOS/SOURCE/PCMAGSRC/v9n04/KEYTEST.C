
/* keytest.c */
#define MSC

#include<conio.h>
#include<stdio.h>

#if	!defined(TRUE)
#define TRUE 1
#endif

#define	SCANCODE(value)	    (value | 0x100)
#define IsScan(value)	    (value & 0x100)
#define	NoScan(value)	    (value & ~0x100)

#define CTL(value)          (value-'A'+1)
#define HOME                SCANCODE(71)
#define END                 SCANCODE(79)
#define PGUP                SCANCODE(73)
#define PGDN                SCANCODE(81)


void main(void);
int inkey(void);

void main(void)
	{

	int c;

	while(TRUE)
		{
        c = inkey();
        if(IsScan(c))
            printf("%d received for scan code %d\n",c,NoScan(c));
        else
            printf("%c = %d\n",c,c);
        if(c == CTL('C'))
            break;
        switch(c)
            {
            case HOME:
                printf("HOME pressed\n");
                break;
            case END:
                printf("END pressed\n");
                break;
            case PGUP:
                printf("PGUP pressed\n");
                break;
            case PGDN:
                printf("PGDN pressed\n");
                break;
            }
		}
	}


int inkey(void)
	{
#if defined(TC)
	_AH = 0;
	asm int 16h
	if(!_AL)
		return SCANCODE(_AH);
	return _AL;
#endif

#if defined(MSC)
#include<dos.h>

	union REGS r;

	r.h.ah = 0;
	int86(0x16,&r,&r);
	if(!r.h.al)
		return SCANCODE(r.h.ah);
	return r.h.al;
#endif
	}


