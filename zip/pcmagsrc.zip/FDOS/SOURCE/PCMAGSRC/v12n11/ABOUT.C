#include "animator.h"

//////////////////////////////////////////////////////////////////////////
// About - Window procedure for the about box shown when choosing 
//         File About...
//////////////////////////////////////////////////////////////////////////

BOOL _export CALLBACK About(DLGPROC_PARAMS)
{
	if (uMsg == WM_COMMAND && wParam == IDOK)
	{
		EndDialog (hDlg, TRUE);
		return TRUE;
	}
	return FALSE;
}
