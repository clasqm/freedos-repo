/* used.c
   calculates total bytes occupied by filespec passed on command line
   If no parameter is passed, defaults to '*.*'
 */

#include <dos.h>
#include <stdio.h>

main(argc,argv)
int argc;
char *argv[];
{
    struct find_t SpaceUsedBy;
    long total = 0L;

    if (argc < 2)
    {
        printf("\nUsage: used <filespec>\n");
        exit(1);
    }

    if(!_dos_findfirst(argv[1],_A_NORMAL,&SpaceUsedBy))
        total = SpaceUsedBy.size;

    while(!_dos_findnext(&SpaceUsedBy))
        total += SpaceUsedBy.size;

    printf("\n%s uses %ld bytes\n",argv[1],total);
}

