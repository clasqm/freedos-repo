typedef struct _employees
{
    char empl_fname[15];
    char empl_init[3];
    char empl_lname[15];
    unsigned empl_no;
    char  empl_ssno[12];
} EMPLOYEES;

typedef struct _clients
{
    char    client_name[30];
    char    client_address[20];
    char    client_city[15];
    char    client_state[3];
    char    client_zip[10];
    long    client_no;
} CLIENTS;

typedef struct _sales
{
    long    sales_no;
    long    sales_date;
    long    sales_invno;
    long    sales_client_no;
    unsigned    sales_emplno;
} SALES;


typedef union _records
{
    EMPLOYEES    employees;
    CLIENTS      clients;
    SALES        sales;
} RECORDS;

#define MAXRECORDS 100

RECORDS records[MAXRECORDS];

main()
{
    printf("Data type:      Size (in bytes):\n");
    printf("  Char           %d\n",sizeof(char));
    printf("   Int           %d\n",sizeof(int));
    printf("  Long           %d\n",sizeof(long));
    printf("  Float          %d\n",sizeof(float));
    printf(" Double          %d\n",sizeof(double));
    printf("EMPLOYEES        %d\n",sizeof(EMPLOYEES));
    printf(" CLIENTS         %d\n",sizeof(CLIENTS));
    printf("  SALES          %d\n",sizeof(SALES));
    printf(" RECORDS         %d\n",sizeof(RECORDS));
}
