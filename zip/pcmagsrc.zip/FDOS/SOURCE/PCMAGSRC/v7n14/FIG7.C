void add_employee(int offset, char *fname, char *init,
    char *lname, unsigned no, char *ssn)
{
    strcpy(records[offset].employees.empl_fname,fname);
    strcpy(records[offset].employees.empl_init,init);
    strcpy(records[offset].employees.empl_lname,lname);
    records[offset].employees.empl_no = no;
}


void add_sales(int offset,long no,long date,long invno,
    long client_no,unsigned emplno)
{
    records[offset].sales.sales_no = no;
    records[offset].sales.sales_date = date;
    records[offset].sales.sales_invno = invno;
    records[offset].sales.sales_client_no = client_no;
    records[offset].sales.sales_emplno = emplno;
}
