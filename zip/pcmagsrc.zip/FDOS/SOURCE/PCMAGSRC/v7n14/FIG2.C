/*
   Use values from 1 to 65534 for the small and medium
   models.  Large model programs should one or more
   large_arrays with values of 65534 for all but the last which
   should be from 1 to 65534.  If the 'huge' data type is
   available, use it and set the value as high as possible.
 */
#define ARRAY_SIZE 30000

char large_array[ARRAY_SIZE];
main()
{
     /* replace this dummy with your program here */
}
