/* Microsoft C programs to test the ADA pragma interface */ 

#include <stdio.h>

void cflttst(x,y)
double far *x, *y;
{
      printf(">  Beginning of cflttst.\n");
      printf(">    Values passed from msctest:\n");
      printf(">      x (1.23456) = %g\n", *x);
      printf(">      y (9.87654) = %g\n", *y);
      *x = 8.76543;
      *y = 2.34567;
      printf(">  End of cflttst.\n");
}
 
int cinttst1(x)
int x;
{
      printf(">  Beginning of cinttst1.\n");
      printf(">    Value passed from msctest:\n");
      printf(">      x (4) = %d\n", x);
      printf(">  End of cinttst1.\n");
      return x * x;
}

void cinttst2(x, y, z)
int x, y, *z;
{
      printf(">  Beginning of cinttst2.\n");
      printf(">    Values passed from msctest:\n");
      printf(">      x ( 5) = %d\n", x);
      printf(">      y (11) = %d\n", y);
      printf(">  End of cinttst2.\n");
      *z = x * y;
}

