#include "windows.h"
#include "gmhook.h"

FARPROC     lpfnOldGMHook  = 0;
HWND        hwndCallBackGM = 0;
BOOL        bGMHookActive  = FALSE;
unsigned    usMsgGM        = 0;
WORD        _acrtused      = 0;

DWORD   FAR PASCAL whGetMessageHook(int iCode, WORD wParm, LPMSG lParm)
{
    if (iCode < 0) {
        return(DefHookProc(iCode, wParm, (LONG)lParm, &lpfnOldGMHook));
    }
    if ((iCode == HC_ACTION) && bGMHookActive) {
        if (lParm) {
            if (lParm->message == WM_NCRBUTTONDBLCLK) {
                PostMessage(hwndCallBackGM, usMsgGM, 0, 0L);
            }
        }
    }
    return(DefHookProc(iCode, wParm, (LONG)lParm, &lpfnOldGMHook));
}

VOID FAR PASCAL whInstallGMHook(HWND hwnd, unsigned msg)
{
    lpfnOldGMHook = SetWindowsHook(WH_GETMESSAGE, (FARPROC)whGetMessageHook);
    hwndCallBackGM = hwnd;
    usMsgGM        = msg;
}

VOID FAR PASCAL whRemoveGMHook(VOID)
{
    UnhookWindowsHook(WH_GETMESSAGE, (FARPROC)whGetMessageHook);
}

BOOL FAR PASCAL whEnableGMHook(BOOL bEnable)
{
    return(bGMHookActive = bEnable);
}

int FAR PASCAL LibMain(HANDLE hModule,  WORD wDataSeg, 
                       WORD cbHeapSize, LPSTR lpszCmdLine)
{
    return(1);
}

int FAR PASCAL WEP(int bSystemExit)
{
    return(1);
}

