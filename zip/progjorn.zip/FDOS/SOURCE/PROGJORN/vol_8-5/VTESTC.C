#include <stdio.h>
#include "virt.h"

main ()
{
        void *handle;
        long x;
        long *p;
        
        vopen();
        
        /* allocate a 100,000-element array of longs */
        
        if ( !(handle = vmalloc(100000L, sizeof(long)) ) )
            perror("vmalloc()");
                                
        /* assign array[10] and array[99,999] to 0 */

        x = *(long *)vread(handle, 10L);
        x = 0;
        vwrite(handle, 10L, &x);

        x = *(long *)vread(handle, 99999L);
        x = 0;
        vwrite(handle, 99999L, &x);

        /* add 5 to array[10] */

        x = *(long *)vread(handle, 10L);
        x += 5;
        vwrite(handle, 10L, &x);
        
        /* add 5 to array[99999] using the faster method */

        p = (long *)vread(handle, 99999L);
        *p += 5;
        vdirty(handle);

        /* print out the values */
        
        x = *(long *)vread(handle, 10L);
        printf ("x[10] = %d\n",x);
        
        x = *(long *)vread(handle, 99999L);
        printf ("x[99999] = %d\n",x);
        
        vfree(handle);
        
        vclose();
}
