/*	v_save_s.c- Workhorse Function: Save Screen Region */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

void _v_save_scr( iptr image, int row, int col, int nrows, int ncols )
{
    /* Copy the indicated region of the screen into image. */

    int i;
    int buf[ VMAXCOLS ], *bp;

    while( --nrows >= 0 )
    {
        gettext( col+1, row+1, col+ncols, row+1, buf );
        ++row;
        bp = buf;
        for( i = ncols ; --i >= 0 ; )
            *image++ = *bp++;
    }
}
