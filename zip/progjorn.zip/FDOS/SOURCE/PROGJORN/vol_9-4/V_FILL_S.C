/*	v_fill_s.c- Workhorse Function: Fill Screen Region */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

void _v_fill_scr( int c_att, int row, int col, int nrows, int ncols )
{
    /* Fill the indicated region of the screen with c_att, which is
     * a character/attribute pair. row and col start at (0,0)
     */

    int i;
    int buf[ VMAXCOLS ], *bp;

    bp = buf;
        for( i = ncols ; --i >= 0 ; )
            *bp++ = c_att;

    for(; --nrows >= 0 ; ++row )
        puttext( col+1, row+1, col+ncols, row+1, buf );
}
