/*	 v_gets.c- Get String from Viewport */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

int v_gets( viewport *v, int n, char *s )
{
    /* Copy at most n-1 characters into s, starting at current cursor
     * position into s. Return number of characters read.
     */

    char *start = s;

    if( v->magic != VMAGIC )
        return 0;

    while( --n > 0 )
    {
        *s++ = v_getc( v );
        if( !v_advance(v) )     /* then we just read the last character */
        {                       /* on the line                          */
            *s = '\0';
            return 0;
        }
    }
    *s = '\0';
    return (s - start);
}
