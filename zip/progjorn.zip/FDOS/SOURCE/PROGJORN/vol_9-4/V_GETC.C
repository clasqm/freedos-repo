/*	v_getc.c- Get Character from Viewport */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

int  v_getc( viewport *v )
{
    /* Return the character at the current cursor position in the
     * indicated window, which is activated if necessary. Cursor
     * position doesn't change.
     */

    int c;
    int col, row;

    if( v->magic != VMAGIC )
        return 0;

    if( v->inactive )
        v_open( v );

    col  = v->col + v->cur_col + 1;
    row  = v->row + v->cur_row + 1;
    gettext( col, row, col, row, &c );

    return c & 0xff ;   /* strip attribute when returning */
}
