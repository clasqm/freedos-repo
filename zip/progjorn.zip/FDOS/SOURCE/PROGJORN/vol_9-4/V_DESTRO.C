/*	v_destroy.c- Destroy a viewport */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

int v_destroy ( viewport *v )
{
    /* Destroy the viewport, freeing all internally allocated memory, but
     * do not free the viewport itself.
     */

    if( v->magic != VMAGIC ){ return 0;  }
    if( !v->closed         ){ v_close( v );  }

    v->magic = ~VMAGIC;      /* guaranteed not to be the same as VMAGIC */
    return 1;
}
