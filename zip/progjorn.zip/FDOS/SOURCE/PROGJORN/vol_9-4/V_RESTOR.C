/*	v_restor.c- Workhorse Function: Restore Screen Region */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

void _v_restore_scr( iptr image, int row, int col, int nrows, int ncols )
{
    /* Like save_scr, but goes in the other direction */

    int i;
    int buf[ VMAXCOLS ], *bp;

    while( --nrows >= 0 )
    {
        bp = buf;
        for( i = ncols ; --i >= 0 ; )
            *bp++ = *image++ ;

        puttext( col+1, row+1, col+ncols, row+1, buf );
        ++row;
    }
}
