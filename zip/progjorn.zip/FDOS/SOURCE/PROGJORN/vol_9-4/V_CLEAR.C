/*	v_clear.c- Clear Viewport */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tools/viewport.h>

int v_clear( viewport *v )
{
    _v_fill_scr( VINIT_CHAR | (v->bcolor << 4 | v->fcolor) << 8,
                                        v->row, v->col, v->nrows, v->ncols );
    return 1;
}

int v_cleartoeol( viewport *v )
{
    _v_fill_scr( VINIT_CHAR | (v->bcolor << 4 | v->fcolor) << 8,
                                v->row + v->cur_row, v->col + v->cur_col,
                                1, v->ncols - v->cur_col );
    return 1;
}
