/*  LISTING 6
 *  Sample embedded SQL syntax in the C Language
 */


     /* variable declarations  /*


        exec sql
             begin declare section;
        struct in_product_rec
                  { char in_product_id;
                    long in_product_price;
                    char in_product_name[20];
                  };
        exec sql
             end   declare section;
 
       /* additional C code here  /*


          . . .


          {
            in_product_rec.in_product_id    = 12;
            in_product_rec.in_product_price = 3000;
            strcpy (product_rec.in_product_name, "PANTS");
            exec sql insert into product
                    (id, price, name )
                 values
                    (:in_product_rec.product_id,
                     :in_product_rec.product_price,
                     :in_product_rec.product_name);
          }
