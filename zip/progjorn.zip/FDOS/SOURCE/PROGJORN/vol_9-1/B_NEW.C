/* b_new.c -- Listing 5. */

#include <stdlib.h>
#include "textbuf.h"

PUBLIC textbuf *b_new( int nrows, int ncols )
{
    textbuf *b;

    if( b = malloc( sizeof(textbuf)) )
        if( !b_construct( b, nrows, ncols ) )
        {
            free( b );
            b = NULL;
        }

    return b;
}
