/*  Consider in C:  */

struct tree {
   char info;
   struct tree *left;
   struct tree *right;
   } node;

typedef struct tree TREE;

TREE *stree(TREE *root, TREE *cur, char info){
   if (!cur){
      if (!(cur = malloc(sizeof(node))) {
         printf("Out of memory\n");
         exit(0);
         }
      cur->left = cur->right = 0;
      if (info<root->info)
         root->left = cur;
      else
         root->right = cur;
      return cur;
      }
   if (info<cur->info)
      stree(cur,cur->left,info);  /* to left */
   else if (info>cur->info)
      stree(cur,cur->right,info); /* to right */
   }


@CODE = void dfo( TREE *root ) {
   if (!root)
      return;
   dfo(root->left);
   printf("info --> %c ",root->info);
   dfo(root->right);
   }

void initialize_tree(void){
   while (!done)
      stree(root,get_next_node(),info)
   dfo(root);
   } 

