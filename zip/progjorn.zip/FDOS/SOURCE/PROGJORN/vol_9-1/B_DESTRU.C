/* b_destruct.c -- Listing 4. */

#include <stdlib.h>
#include "textbuf.h"

PUBLIC b_destruct( textbuf *b )
{
    if( b->buf && b->magic == B_MAGIC )
    {
        BFREE( b->buf );
        b->magic = 0;
        return 1;
    }
    return 0;
}
