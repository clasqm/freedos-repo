/* b_delete.c -- Listing 6. */

#include <stdlib.h>
#include "textbuf.h"

PUBLIC void b_delete( textbuf *b )    /* Free a textbuf allocated by   */
{                                     /* a previous b_malloc().        */
    if( b_destruct( b ) )             /* Explicitly declared textbuf's */
        free( b );                    /* can be destroyed with an ex-  */
}                                     /* plicit b_destruct() call.     */

