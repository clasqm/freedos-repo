/* CDLL.c
 * a skeleton dynlink library written in C
 *
 * By Ray Duncan
 *
 */


int _acrtused = 0;          /* don't link C startup */�
     .
     .
     .

/*
    MYFUNC is exported for dynamic linking
    by application programs.
*/

int far pascal MYFUNC(int a, int b)
{
     .
     .
     .
}

     .
     .
     .
/*
    C_INIT is called from the entry point in CINIT.ASM
    when a client process dynlinks to the library.
*/

int far pascal C_INIT(void)
{
     .
     .
     .
    return(1);              /* return success code */
}

