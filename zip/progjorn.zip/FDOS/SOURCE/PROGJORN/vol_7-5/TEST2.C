/*
    TEST2.C - Same as TEST.C, except using objects
*/

#include "stdio.h"
#include "pubclass.h"

main()
{
    int x;
    Obj item;
    Obj header=New(TwllHead);

    /* add 3 entries of each type to the list*/
    for (x=3;x;x--) {
        item=New(DataTwll);        /* create a new DataTwll Object */
        Send(header,AddItem,item);
        Send(item,SetX,x);

        item=New(MyDataTwll);      /* create a MyDataTwll */
        Send(header,AddItem,item);
        Send(item,SetA,"Sample.");

        item=New(OtherDataTwll);   /* create an OtherDataTwll */
        Send(header,AddItem,item);
        Send(item,SetA,x+100);
        }

    /* print the contents of the list */
    Send(header,SendAll,Print);

    exit(0);
}

