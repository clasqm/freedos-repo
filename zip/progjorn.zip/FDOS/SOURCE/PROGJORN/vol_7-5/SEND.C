
typedef int (*funcp)();

typedef struct METH_T {
    int    msg;                 // msg on top to improve compare time
    funcp  procc;               // pointer to method for msg
    struct METH_T near *next;   // next entry in this hash chain
    } METH_TABLE;               // entry in method table
 
#define MAX_METHS 32            // must be multi of 2
typedef struct class_def {
    METH_TABLE near *tbl;       // pointer to method table for this class
    char       *name;           // asciiz string of class name
    int        size;            // size of objects in this class
    struct class_def  *super;   
    METH_TABLE near *hash[MAX_METHS]; // hash table for method look-ups
    } CLASS_DEF;
 
typedef struct {
    CLASS_DEF near *class;
    } *Obj_x;

/*---------------------------------------------------*/
void *send(obj,msg)
Obj_x obj;
int msg;
{
    METH_TABLE  near *tbl;
    CLASS_DEF	near *clas;
    int hash;

    hash=msg & (MAX_METHS-1);

    clas=obj->class;
    if ( !(tbl=clas->hash[hash]) ) {
        send_org(clas);                     // initialize the hash table
        tbl=clas->hash[hash];
        }

    while (tbl->msg != msg)                 // search hash chain for msg
        tbl=tbl->next;

    (*tbl->procc)();                        // NOTE:
                                            //  need to convert this to a jump
    return;
}
