/* b_last.c-- Find Last Character on Line */

#include <tools/textbuf.h>

b_last( textbuf *b )
{
    bufptr startp = b->buf + (b->ncols * b->row);
    bufptr endp   = startp + (b->ncols);
    while( --endp > startp && isspace(*endp) )
        ;
    return( endp - startp );
}
