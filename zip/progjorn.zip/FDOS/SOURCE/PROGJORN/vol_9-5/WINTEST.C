/* 		wintest.c-- Test main() for Window-Based Editor */


#include <stdio.h>
#include <conio.h>      /* Borland video defines (RED, CYAN, etc.) */
#include <tools/window.h>

/*---------------------------------------------------------------*/
/* Hooks for the file manager. Fill these in if you want an      */
/* underlying file. If not, remover the w_file() call in main(). */

#pragma argsused
static void sigexport( win *this, int line_number, char *line,
                                                int ncols, int len)
{
}

#pragma argsused
static char *sigimport( win *this, int line_number )
{
    static char line[128];
      return line;
}

#pragma argsused
static void sigremove(win *this,int line_number,char *line,
                                                int ncols, int len)
{
}

#pragma argsused
static int  siginsert( win *this, int line_number )
{
}
/*------------------------------------------------------------*/

#define WINSIZE  20     /* 40x40 text buffer */
#define VIEWSIZE 10     /* 10x10 viewport    */

void main()
{
    static int c;
    static win *w;

    w = w_construct(   WINSIZE,  WINSIZE        );
    w_viewsize     (w, VIEWSIZE, VIEWSIZE       );
    w_viewcolor    (w, RED, CYAN                );
    w_move         (w, 1  , 1                   );
    w_file         (w, sigimport, siginsert, sigexport, sigremove);
    w_open         (w );

    while( (c = getch()) != 'q' )
    {
        wputc( w, c );
    }
    w_destroy( w );
}
