Power Menu 1.0c
Copyright (C) 1997-2004 Jem E. Berkes
http://www.pc-tools.net/

Version 1.0c has NOT been tested or officially released.
It supports these new features:

- Pressing a number 1-9 will jump to the corresponding item
- Pressing the Home key will jump to the first entry


Please inform the author if there are any bugs.

Jem Berkes
jberkes@pc-tools.net
