
 Welcome to PTS DiskEditor version 1.04
 -----------------------------------------------------------
 Copyright(C)1998 by PhysTechSoft, Ltd. All rights reserved.

 [ Note: PTS-DiskEditor along with other software from PhysTechSoft was
   sold to a company called "Acronis" a long time ago.  Do not bother
   PhysTechSoft about this disk editor; if they still exist. ]


   Contents
   --------
 1. About PTS DiskEditor
 2. Hardware requirements and compatibility
 3. Installation instructions
 4. Distribution file listing
 5. Contacting the authors
 6. History


 1. About PTS DiskEditor
 -----------------------

 PTS DiskEditor is a program you can use to view and edit the raw contents
 of your hard drives in various situations. For example, to restore useful
 information from damaged logical drives. This copy of the PTS Disk Editor
 is fully functional, but doesn't have some of the newer features found in
 our latest version... and this program is only part of our combined suite
 of advanced products which includes a Disk Administrator and Boot Wizard.
 Please contact the authors if you find any errors or incorrect behaviour.


 2. Hardware requirements and compatibility
 ------------------------------------------

 PTS DiskEditor can be used on any computer with at least an i386 CPU and
 any hard drives supported by the BIOS. A mouse is handy but not necessary.
 PTS DiskEditor itself uses no more than 200 kb of memory.


 3. Installation instructions
 ----------------------------

 There are two ways to use PTS DiskEditor:

 1) Run DE.EXE from MS-DOS (such as the Win98 Boot Disk) or Windows 95/98
    (or compatible) Operating System.  This is probably the ONLY way that
    MOST of you should ever use this disk editor! See CAUTION note below.

   [ NOTE: The PTS DiskEditor will *NOT* function DIRECTLY under Windows
      NT/2000/XP since PTS DiskEditor uses 'disk access functions' which
      these OSs do NOT allow.  However, PTSDE is still very useful in
      repairing the MBR/EMBRs of disks partitioned with WinNT/2000/XP! ]

 2) Boot your computer from a PTS DiskEditor startup diskette. You should
    create this startup diskette using MAKEBOOT.BAT which is included in
    the distribution; specifically you MUST use REINSTAL.COM (see the
    last line of MAKEBOOT.BAT) to turn the diskette into a PTS-BootWizard
    bootdisk so the DiskEditor can function autonomously; without having
    to first boot an operating system.

   [ NOTE: This is NOT recommended since many people inadvertently end
     up installing the 'BootWizard' software on their hard drives. ]


 4. Distribution file list
 -------------------------

 PTS DiskEditor distribution should include all of the following files.
 (If any of them are absent, please notify either your distributor or
  contact us directly.)

 [Editor's Note: If you have MS-DOS, Win 95 or Win98, it's probably best
  to simply extract DE.EXE and run it all by itself after booting DOS.
  Some users have inadvertently installed 'BootWiz' on their hard drives
  and ended up having problems booting their computers!  So, be VERY
  CAREFUL if you decide to use the MAKEBOOT.BAT file; I had to include
  it in order to keep this distribution legal. -- TS / 3 May 2003.]

 MAKEBOOT.BAT - Batch file to create a PTS DiskEditor startup diskette.
 BOOTWIZ.CFG  - Floppy configuration
 REINSTAL.COM - Special utility
 DE.EXE       - PTS DiskEditor itself
 BOOTWIZ.SYS  - Loader program
 LICENSE.TXT  - License agreement
 README.TXT   - This file


 5. Contacting the authors [Note: Software was sold to Acronis long ago.]
-------------------------

 Our address:
   PhysTechSoft, Ltd,
   Institutsky per., 9
   Dolgoprudny, 141700, RUSSIA

 Phone/Fax:
   +7 (095) 408-7072
   +7 (095) 576-5518

 Check out our Internet site:
   http://www.PhysTechSoft.com  (USA)    -- No longer valid.
   http://www2.PhysTechSoft.com (Russia)

 E-mail:
   bootwiz@PhysTechSoft.com


 6. History
 ----------

 1.04 - Several bug fixes.
 1.03 - Several bug fixes.
 1.02 - Several bug fixes, write operation enabled in Win95/98.
 1.01 - First stable version.



[Updated: 6 JUNE 2003. The Starman.]