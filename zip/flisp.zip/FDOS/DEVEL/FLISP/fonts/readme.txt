**************************************************************************

       FLISP font utilities. Copyright (C) 2005 Francesco Zamblera
                            (vilnergoy@yahoo.it).

    This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

    This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

**************************************************************************


    This directory contains the following files:

    readme.txt (this file)
    rus.fnt
    rus.key
    gnuchcp3.exe
    gnuchcp3.pas
    loadf.bat
    unloadf.bat

    These files are provided for use by the FLISP interpreter, but they can
also be used alone, via the scripts LOADF and UNLOADF.

    In this release, only cyrillic fonts and keyboards are provided. In
later releases, more fonts and keyboards will be included, as well as a
bitmap font editor.

   .fnt are pure binary data files, 8x16 bitmap fonts. Each file's size is
2k, because only ASCII 128-255 characters are encoded.

   .key are keyboard drivers written for XKEYB. The Russian keyboard included
in the packet works as follows: to get lower-case Cyrillic characters, press
Alt + the character you want (e.g. Alt-a is Cyrillic "a", Alt-i is Cyrillic
"i", and so on). To get upper-case Cyrillic, press AltGr + the letter you
want. Without and Alt key, the keyboard gives Latin characters. So you can
use Latin and Cyrillic characters in the same text, without having to change
keyboard every time.
   Have a look at rus.key to see combinations (e.g. to get the Cyrillic "ja",
just type "j" then "a", always keeping the ALT key pressed down).

   .key files are written according to the instructions you will find in the
FreeDOS XKEYB utility documentation. The keyboard layout which has been taken
as a reference is the American one. If you have, for example, an Italian
keyboard, you will have to rewrite the .kbd file (in later releases I hope
to be able to provide a program which does this automatically, at least for
the commonest layouts).

   The character code in rus.fnt and rus.key corresponds to CodePage 866.
