MPXPLAY Audio player version 1.45 by PDSoft

Supported filetypes:

MP2,MP3  (Audio MPEG Layer II/III)
OGG      (Ogg Vorbis by http://www.xiph.org)
MPC      (MPEGPlus by http://www.mpegplus.net)
WAV      (uncompressed wave files)
CDW      (Audio-CD 'ripp and play' on the fly)

Send suggestions and error reports to 

  mpxplay@freemail.hu   (please don't public this email address (ie

: don't put it on your web page))

important notes and requests before you send me mail:
 - Write MPXPLAY on the subject line!!!
 - before You ask something from me or you would like to send me 
   a bug report, 
   please read README.TXT (this), MOREINFO.TXT and FAQ.TXT files!
 - don't send attachments (only if I ask for it)
 - sorry, but I can't answer to everybody, I read your 
   requests/problems,
   but don't wait answer from me ...
   (Usually I don't answer, if your question is answered somewhere 
   in the text files or I can't help you at all (especially with 
   hardware problems))

Visit my homepages:

      http://mpxplay.cjb.net   <- this address is linked to my 
actual main page

      http://mpxplay.tripod.com
      http://www.geocities.com/mpxplay
      http://ganymede.spaceports.com/~mpxplay
      http://www.tar.hu/mpxplay

for the updated versions.

Mpxplay system requirements:

- CPU: for MP3: Intel 80486 DX2-80 (DX4-100)
       for MP2: Intel 80486 DX2-50 (DX2-66)
       for OGG: Intel Pentium class (>90mhz)
       for MPC: Intel 80486 DX4-120
- Soundcard:
   - SB16 ISA (not PCI) or compatible (DSP 4.x), AWE-32/64, SB Live

 (SB16 emu)
   - ESS 688,1688,1868,1869,1878,1879,1887,1888 chips (?)
   - WSS compatible (Crystal Sound, Yamaha OPL3, CMI8330 (?), some 

ESS cards (?))
   - GUS (GUS MAX, GUS PnP (AMD Interwave))
   - SB Pro or compatible (DSP 1.x, 2.x, 3.x)
   ((?) means: not tested, maybe it doesn't work properly)
- Memory:
   - 200kbyte conventional
   - 2Mb XMS (+0.5Mb for MIDAS)(+2*1Mb for -bp)(+size_of_file at -b

l)
- Display: VGA (or EGA)
- OS: MS-DOS 5.x,6.x, Windows 95/98 (dos box)
  (if you get memory allocation errors in MS-DOS 7.xx, use the DOS4

GW version (mpxp_4gw.zip))

Command line options:

usage: MPXPLAY.EXE [option(s)] audiofile    (play one audio file 
[.mp3,.wav,.cdw])
   or: MPXPLAY.EXE [option(s)] playlist.m3u (load a playlist file)
   or: MPXPLAY.EXE [option(s)] d:\*.*\*.*   (scan (sub)directories 

for files)
   or: MPXPLAY.EXE [option(s)] -ds cde      (scan c: d: e: drives 
for files)
   or: MPXPLAY.EXE [option(s)] d:\*.cdw     (play all audio CD trac
ks)
   or: MPXPLAY.EXE -o -sl 0 in.mp3 out.wav  (decode mp3 to a wav 
file)
   or: MPXPLAY.EXE -o -sl 0 d:\1.cdw 1.wav  (copy the 1. audio CD t

rack into a wav file (ripp))

for slow computers (486DX4-100 or bellow)(-bl requires 7-10Mb RAM (

3Mb + size of MP3)):
       MPXPLAY.EXE -sl 0 -ddma -f0 -v -bl -bni playlist.m3u
    or:MPXPLAY.EXE -sl 0 -ddma -f0 -v playlist.m3u

for faster computers (Pentium or above):
       MPXPLAY.EXE -bp -ipl playlist.m3u

Playlist functions:
 -@  PLAYLIST : use a playlist (.m3u or .mxu)
 -@d PLAYLIST : doombox (jukebox) mode (load playlist to the left s

ide, push song to queue)
 -@s PLAYLIST.M3U : save playlist from editor into PLAYLIST file on

 exit (default:MPXPLAY.M3U)
 -@sx PLAYLIST.MXU: save playlist in extended mode (playlist with f

ile infos)
 -ds DRIVES : multiple drive scan (-ds cde -> scans c: d: e: drives

)(-ds cde *.wav -> search wav files only)
 -dd use doombox mode (load files to the left side)(at drive scan (

-ds) and directory browser)
 -prn  random play
 -prn2 randomize playlist at start
 -pre  replay playlist (after the last song the playing jumps to th

e first song)
 -pre1 repeat only 1 song (rewind to the begin of file)
 -pss NUM : start play at NUM. song  (PlayStartSong)
 -psc NUM : exit after NUM song      (PlaySongCount)
 -psp NUM : start song at NUM-16%    (PlayStartPercent)(16% is the 

begin of the song)
 -psf NUM : start song at NUM. frame (PlayStartFrame)
 -pfc NUM : play NUM frames only     (PlayFrameCount)
 -pef NUM : finish playing at NUM. frame (PlayEndFrame)(PlayFrameCo

unt=PlayEndFrame-PlayStartFrame)(doesn't work with -psp)
 -phs hi-lite scan : play only 10 seconds from every songs (1m00s-1

m10s)(configurable with -psf and -pfc options)
 -pap enable auto pause (auto pause before each song)

Display settings:
 -f0  no screen output
 -ff  only framepos and actual filename are displayed
 -fl  one line display output
 -v   verbose mode (mpeg info,id3tag info for -f0,-ff or -fl option

s)
 -fe  full screen playlist-editor (without spectrum-analiser & brow

ser)
 -fs  single lines mode (disable 50 lines mode change at start) (25

->50)
 -db  disable directory browser in playlist editor (left side)
 -ebs num : editor border size (14-67)(def:67)

Input buffer settings (def. (4*32=)128kbyte prebuffer without inter

rupt decoding):
 -bn  no input buffer (not recommended)
 -bp  input file pre(ring)buffer (decoder runs in interrupt)
 -bl  input fullbuffer (it loads the (whole) song into memory befor

e playing (max. 13mbyte))
 -bni disable interrupt decoding (for -bl)
 -bbn prebuffer blocks (1 block=32kbytes)(use: 8 - 64 (MP3-WAV))(de

f.: 4; -bp: 32)

Sound card and output settings:
 -scs CARD manual soundcard select (S16,ESS,WSS,GUS,SBP,MID,NUL)
 -sct CARD soundcard test (without CARD argument it tests and displ

ays all possible cards)
 -scm  configure manually MIDAS and save it to MPXMIDAS.INI file (c

urrently doesn't work)
 -scv num  sound card volume (master & voice)(1-100(%))
 -sctr num sound card treble (1-199(%)) (old SB16 (OPL) & AWE32/64 

only)
 -scbs num sound card bass   (1-199(%))
 -ddma     double dma (32k->64k) (soundcard buffer)
 -t        testmode (no sound output, only decoding)
 -o        write pcm data to a wav file

Sound mixing and output modifying:
 -sv  volnum   software volume setting (amplifying)(0-600)(def. 100

 (%))
 -sva [volnum] auto volume correction [with initial volume]
 -sr  surnum   surround (def.:100 (%) = no surround, 10=mono, 150=w

ide stereo)
 -sp  speed    playing speed (freq) control (60-200)(def.:100 (%))
 -sl  limit    soundlimit (playlimit)(0-200)(def.:20)

 -cl  decode channel left only (works at mp3 only)
 -cm  downmix channels (stereo to mono) (works at mp3 only)
 -hq  (currently for mp2 files only)

 -cf  auto crossfade at the end of files
 -cfp [num] crossfade point (def. 120)(start crossfade at num. fram

e, relative to begining of fade-out)
 -cfo [num] fade-out length (def. 250)
 -cfi [num] fade-in length  (def. 200)
 -cfl [num] crossfade limit (def. 0) (start crossfade, when volume 

less than num (don't use crossfade point))
 -cft [num] crossfadetype   (def. 1) (0.bit:fade out, 1.bit:fade-in

)(-cft 3 : fade out+in)
 (crossfade only: -cfo 150 -cfp 0 -cfi 150 , fade-out & fade-in onl

y: -cfo 150 -cfp 150 -cfi 100 )

ID3-info, file-info and ID3-list settings:
 -ipl load file infos under play (start playing 1. song, after load

 infos)
 -ini don't preload file informations in playlist (header,id3tag)(l

oad at playing)
 -in  don't load id3tag info from mpeg files (but -il works)
 -il  [infofile] load LOCAL id3info listfile (for current directory

 entries, reload after every dir change)
 -ig  [infofile] load GLOBAL id3info listfile (for playlist entries

)(create:mpxplay -@ playlist.m3u -is d:listfile.txt -ist 448)
 -is  [infofile] save id3 infos to a listfile
 -iw  [infofile] write id3tag into mpeg files (mp2,mp3,mpc) (load i

t from the infofile)
     (default [infofile] name is: !FILES)
 -io NUM  order playlist by 0=title, 1=artist, 2=album, 3=year, 4=c

omment, 5=genre (style), 6=time, 7=filesize, 8=filename, 9=path\fil

ename
 -ist NUM type for id3 savelist (the bits of the NUM changes the ty

pe)(def.:63)
   0. bit (  +1): list directory names
   1. bit (  +2): list filenames
   2. bit (  +4): artist-title list mode (non-fixed/fixed position)


   3. bit (  +8): list time of file
   4. bit ( +16): list bitrate (kbit/s)
   5. bit ( +32): list filesize in megabytes
   6. bit ( +64): list filenames with full path

 -8  convert windows characters to dos characters (codepage convers

ion in ID3 tags)
     (configure it in the mpxplay.ini (WinChars/DosChars))

Other settings:
 -x PRGNAME : set program name for DOS shell (i.e. -x nc.exe)
 -xs : load song (playlist), jump to DOS shell automatically (use w

ith -bl)
 -xr : TSR mode (for CDW files only)
  (or 'mpxplay.exe -bl -xr -xs -pre1 song.mp3' for continuous backg

round playing)


Keyboard controls (some keys are case sensitive (lower case only)!)


(suggestion: set the keyboard speed to 30 char/sec in BIOS):

 ESC      - exit
 CTRL-C   - exit
 gray-'-' - step back one song in playlist
 gray-'+' - step forward one song in playlist
 white-'-'- step back like a CD player (if framenum>38, step to beg

in of song, else step to previous song)
 gray-'/' - step back one subdirectory (album) in playlist
 gray-'*' - step forward one subdirectory (album) in playlist
      ->  - forward (right arrow) (50 frames)
      <-  - rewind  (left arrow)
 CTRL- -> - fast forward (200 frames)
 CTRL- <- - fast rewind 
 BACKSPACE- skip to begining of the song
  A       - spectrum analiser enable/disable
  C       - crossfader enable/disable
  d       - hi-lite scan start/stop
 CTRL-'D' - open a DOS-shell
  E       - editor filenames enable/disable
  F       - (cross) fade out/in enable/disable
  H       - sound correction (hq) (currently for mp2 files)
 CTLR-'L' - reload playlist or rescan directories/drive(s) (at disk

 change)
  M       - mute sound (1/8 sound volume)
  N       - random (shuffle) play enable/disable
  o       - open/close CD door
  P       - start/pause playing
 CTRL-'P' - enable/disable autopause (it has no indicator on displa

y)
  R       - replay (repeat) enable/disable (select 1 song/full play

list replay)
 CTRL-'R' - (re)order the playlist (depends on the ID3ordertype (-i

o))
  S       - stop playing (jump to begin of playlist)
 CTRL-'S' - pause playing at (before) next song
  T       - time mode (elapsed,remaining,allelapsed,allremaining)
  V       - auto volume enable/disable
  X       - swap channels (reverse stereo)
  .       - volume up   ('white home' too)
  ,       - volume down ('white end' too)
 CTRL-V   - reset volume, surround, treble, bass and speed to 100%
  '       - surround up   (superb stereo)
  ;       - surround down (to mono)
  ]       - playing speed up
  [       - playing speed down
  >       - bass up    (hardware tone on SB16 (OPL chipset), AWE32/

64)
  <       - bass down
  "       - treble up
  :       - treble down
 NUMBER   - type a playlist-entry number (1-9999)(step to n. song)

   ALT-F9 - 25/50 lines mode switch
  CTRL-F9 - full screen playlist-editor mode (analiser and browser 

disabled)
 SHIFT-f9 - equal to ALT-F9 + CTRL-F9

 Unofficial key:
  I       - enable/disable hq mixer

 Editor keys: 
  Up & Down arrows  : move cursor up/down 1 song in the playlist
  PageUp,PageDown   :       -"-           1 editor page (1 page=30 

song on the default screen)
  ALT-gray-PgUp/PgDn:       -"-           1 album (subdir differenc

e in the playlist)
  Home,End          :       -"-           to the top/bottom of play

list
  CTRL-PgUp/PgDn    : move to updir/subdir or uplist/sublist
  CTRL-'\'          : jump to root dir/list (directory browser/subl

ist structure)
  TAB               : change editorside

  ENTER or SPACE      : start the selected song OR load playlist OR

 change dir
  CTRL-ENTER          : select next song

  F5 or Ins           : add a file/playlist/subdir to the other sid

e
  F8 or Del           : delete a file from playlist
  CTRL-F5 or CTRL-Ins : copy all playlist entries to the other side


  CTRL-Del            : clear playlist
  CTRL-UP / DOWN      : shift (drag and move) a song up/down in pla

ylist

  ALT-LEFT / RIGHT    : modify size of playlist-editorsides
  ALT-UP / DOWN       : resize playlist editor/song browser
  ALT-'A'-'Z'         : search artist (or filename) in playlist by 

typed string

 Mouse buttons:   
  left button: 
   in fullscreen mode:
     - one click on position line () to move in song (to set a new

 position)
     - one click on browser to skip to (select and start) a new son

g
     - one click in the playlist to move the editor highline (and c

hange editorside)
     - double click in the playlist to start a new (selected) song
   in non-fullscreen mode (-f0,-ff,-fl):
     - short press (click) : pause playing
     - long press (hold on) : mute sound

  center button: step back in playlist   / fast rewind    (click/lo

ng press)
  right button:  step forward in playlist/ fast forward
