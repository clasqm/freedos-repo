trace o
"cat links (stack"
links.0 = queued()
do i=1 to links.0
	parse pull link.i text.i
end
"mkdir new"

do l=2 to links.0
	fin = open(link.l,"r")
	fout = open("new/"link.l,"w")

	lp = l - 1
	ln = l + 1

	do forever
		line = read(fin)
		if eof(fin) then leave
		if line="<BODY>" then do
			call write fout,line,nl
			call write fout,'<TABLE>',nl
			call write fout,'<TD><A HREF="'link.lp'"> Previous </A>',nl
			call write fout,'<TD><A HREF="'link.1'"> Top </A>',nl
			if ln <= links.0 then
				call write fout,'<TD><A HREF="'link.ln'"> Next </A>',nl
			call write fout,'</TABLE>',nl
			call write fout,'<HR>',nl
		end; else
		if line="</BODY>" then do
			call write fout,'<HR>',nl
			call write fout,'<TABLE>',nl
			call write fout,'<TD><A HREF="'link.lp'"> Previous </A>',nl
			call write fout,'<TD><A HREF="'link.1'"> Top </A>',nl
			if ln <= links.0 then
				call write fout,'<TD><A HREF="'link.ln'"> Next </A>',nl
			call write fout,'</TABLE>',nl
			call write fout,line,nl
		end; else
		call write fout,line,nl
	end

	call close fin
	call close fout
end
