/*
        ALTCHAR.C   Ver. 1.22   18-FEB-1989

        Software Innovations Technology
        1083 Mandarin Drive NE, Palm Bay, FL 32905-4706   (407)951-0233

        This file is for use with UNIX.ADA.

        ALTCHAR.C is a simple solution to the single-character input problem.
        It was sent to us by Mr. Richard Conn, 2700 Bowline Court, Maineville,
        OH  45039.  Software Innovations Technology is grateful to Mr. Conn for
        permission to include ALTCHAR.C with ADA-TUTR.

        For this to work, surround the ada_tutr invocation with
                stty raw
                ada_tutr
                stty -raw
*/
#include <stdio.h>

char onechar()
{
        char c;

        c = getchar();
        return (c);
}
