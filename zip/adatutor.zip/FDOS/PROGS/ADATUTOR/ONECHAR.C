/*
ONECHAR.C   Ver. 1.22   18-FEB-1989

Software Innovations Technology
1083 Mandarin Drive NE, Palm Bay, FL 32905-4706   (407)951-0233

This file is for use with UNIX.ADA.  It is a Unix System V routine to allow
the capture and return of one character from the terminal.

This program was written by Dave Hill, 7549 Wynford Street, Salt Lake City, UT
84121.  Software Innovations Technology is grateful to Mr. Hill for permission
to include ONECHAR.C with ADA-TUTR.
*/

#include <stdio.h>
#include <termio.h>
char onechar()
{
    static struct termio newsets, oldsets;
    char c;
    ioctl(fileno(stdin), TCGETA, &newsets);
    ioctl(fileno(stdin), TCGETA, &oldsets); /* used by cooked */
    newsets.c_cc[4] = '\001';
    newsets.c_cc[5] = '\0';
    newsets.c_lflag &= ~ (ICANON);
    ioctl(fileno(stdin), TCSETAF, &newsets);
    c = getchar();
    ioctl(fileno(stdin), TCSETAF, &oldsets);
    return (c);
}
